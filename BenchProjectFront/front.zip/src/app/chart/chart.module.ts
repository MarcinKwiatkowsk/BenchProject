import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ],
  
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
})
export class ChartModule { }
