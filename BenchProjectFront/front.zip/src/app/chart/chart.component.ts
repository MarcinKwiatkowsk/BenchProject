import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import { Options } from "highcharts/highstock";
import { StockChart } from 'highcharts';
import { TickService } from '../tick/tick.service';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

@Component({
  selector: 'app-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.css'],
})
export class ChartComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
  
  Highcharts: typeof Highcharts = Highcharts;

  chartOptions ={
    title: {text: "MARKET GOOGLE VALUE"},
    xAxis: {
      categories:["1.01.2022", "2.01.2022", "3.01.2022"],
      title: {text: "date:"}
    },
    yAxis: { 
      title: {text: "value:"}
    },
    series: [{
      name: "Ticks",
      data: [1,2,3]
    }],

  }



  

}

