import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { Tick } from './tick.model';

@Injectable()
export class TickService {
  constructor(private http: HttpClient) {}

  readonly baseURL = 'https://localhost:44377/Ticker';

  getTickers() {
    let list: Tick[];
    var ticks = this.http.get(this.baseURL);
  }
}
