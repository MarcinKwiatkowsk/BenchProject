import {Component, OnInit} from '@angular/core';
import { TickService } from './tick.service';

@Component ({
    selector: 'app-tick',
    templateUrl: '/tick.component.html',
    styles: []
})

export class TickComponent implements OnInit {
    constructor(public service: TickService) {}

    ngOnInit(): void {
        
    }
}