export class Tick{
    TickId: string ='';
    TickDateTime: string ='';
    TickValue: number =0;
}